<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>The Pragmatic Programmer     </title>
      <!--========== BOX ICONS ==========-->
      <link rel="stylesheet" href="../css/boxicons.min.css">
      <!--========== CSS ==========-->
     
      <link rel="stylesheet" href="../css/style.css">
      <link rel="stylesheet" href="../css/main.css">
      <!-- Google Fonts-->
       <link rel="preconnect" href="https://fonts.googleapis.com">
       <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
       <link href="https://fonts.googleapis.com/css2?family=Jomhuria&family=Work+Sans:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
   <!-- Start Header -->
   
   <div class="header1" id="header1">
    <div class="container1">
        <a href="../../index.php" class="logo1"><img class="logo1" src="../img/EbookStore.png"   alt="logowesite" ></a>
        <ul class="main-nav1">
            <li>
                <a href="arabic.html">الكتب العربية</a>   
             </li>
             
            
            <li><a href="french.html">LIVRE FRANÇAIS</a>
               
            </li>
            <li><a href="english.html">LIVRE ENGLAIS</a>
               
            </li>
            <li><a href="nevau.html">NOUVEAUTÉS</a></li>
        </ul>
            <input class="sherche1" type="text" placeholder="Recherche...">
        <ul class="main-nav1">    
            <li><a href="../login.html"><i class='bx bx-user-circle bx-md'></i>Mon compte</a></li>
            <li><a href="#"><i class='bx bx-heart bx-sm' ></i></a></li>
            <li>
                <a href="#" class="cart1">
                  <i class='bx bx-basket bx-sm' ></i>
                  <span class="count1">10</span>
                </a>
            </li>
        </ul>
    </div>

</div>
<!-- End Header -->
     <main class="container">
 
          <!-- Left Column / Headphones Image -->
          <div class="left-column">
          
            <img data-image="red" class="active"  src="../img/tpp.jpg" alt="">
          </div>
         
         
          <!-- Right Column -->
          <div class="right-column">
         
            <!-- Product Description -->
            <div class="product-description">
             
              <h2>The Pragmatic Programmer</h2>
              <h3>160,00 MAD</h3>
              <p>Straight from the programming trenches, The Pragmatic Programmer cuts through the increasing specialization and technicalities of modern software development to examine the core process--taking a requirement and producing working, maintainable code that delights its users. It covers topics ranging from personal responsibility and career development to architectural techniques for keeping your code flexible and easy to adapt and reuse.</p>
              
          
          </div>
             <p>DISPONIBILITÉ:<b>EN STOCK</b></p>
             <p>REF.:<b>9789778200935</b></p>


         
       
         
            <!-- Product Pricing -->
            <div class="product-price">
               
              <a href="#" class="cart-btn"><i class='bx bx-basket' ></i> AJOUTER AU PANIER</a>
             
              <a href="#" class="cart-btn">PROCÉDER AU PAIEMENT</a>
            </div>

            <!--
              Plus d’information
              Auteur	malala yousafzai
              Editeur	Indigo
              Discipline	Politique
              ISBN	9781510101692
              Année d’édition	2015
              Thème	Biographie
              Couverture	Broché
            -->

            
                <h4 class="subtitle">PLUS D’INFORMATION</h4>

                <p> <span class="edit-font"> Auteur: </span>  David Thomas, Andrew Hunt</p>
                <p> <span class="edit-font"> Editeur: </span>  Pragmatic Bookshelf</p>
                <p> <span class="edit-font"> Discipline: </span> Sciences & Techniques </p>
                <p> <span class="edit-font"> ISBN </span>  -10: 0-13-595705-2</p>
                <p> <span class="edit-font">Année d’édition: </span>  2019</p>
                <p> <span class="edit-font"> Thème: </span>  Langue Anglaise</p>

                <h5></h5>

            </div>


          </div>
        </main> 

        <

         <!-- STRAT FOOTER -->
         <div class="footer">
          <div class="container1">
            <img  src="../img/EbookStore.png" width="150px" alt="logowesite" >
            <p>Ebookstore de votre plus grande bibliothèque en ligne</p>
            
            <div class="social-icons">
             <a href="#"><i class='bx bxs-home' ></i></a>
             <a href="#"><i class='bx bxl-facebook-circle'></i></a>
             <a href="#"></a> <i class='bx bxl-twitter' ></i></a>
             <a href="#"></a> <i class='bx bxl-instagram-alt' ></i></a>
            </div>
            <p class="copyright">&copy; 2022 <span>ebookstore</span> All Right Reserved</p>

          </div>

        </div>




        <!-- END FOOTER -->
</body>
</html>