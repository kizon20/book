<!DOCTYPE html>
<html lang="ar">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>ebookstore</title>
        <!--========== BOX ICONS ==========-->
        <link rel="stylesheet" href="../css/boxicons.min.css">
       <!--========== CSS ==========-->
       <link rel="stylesheet" href="../css/main.css">
       <!-- Google Fonts-->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Jomhuria&family=Work+Sans:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Start Header -->
    <div class="header1" id="header1">
        <div class="container1">
          <a href="../../index.php" class="logo1"><img class="logo1" src="../img/EbookStore.png"   alt="logowesite" ></a>
          <ul class="main-nav1">
                <li>
                    <a href="arabic.php">الكتب العربية</a>   
                 </li>
                 
                
                <li><a href="french.php">LIVRE FRANÇAIS</a>
                   
                </li>
                <li><a href="english.php">LIVRE ENGLAIS</a>
                   
                </li>
                <li><a href="nevau.php">NOUVEAUTÉS</a></li>
            </ul>
                <input class="sherche1" type="text" placeholder="Recherche...">
            <ul class="main-nav1">    
                <li><a href="../login.php"><i class='bx bx-user-circle bx-md'></i>Mon compte</a></li>
                <li>
                    <a href="#" class="cart1">
                      <i class='bx bx-basket bx-sm' ></i>
                    </a>
                </li>
            </ul>
        </div>

    </div>
    <!-- End Header -->


    <div class="container mx-auto  ">

       <?php
       include('../../modele/conect.php');
    //    include('../modele/');
            $con = conect();
            $sql = "SELECT * FROM livre WHERE  discipline= 'Arabic' ";
            $tab = $con->query($sql)->fetchAll(PDO::FETCH_ASSOC);
            foreach ($tab  as $row) {

            ?>


        <form action="" method="post" style="display:grid;
                        grid-row:1 ;
                        grid-template-columns: repeat(auto-fill,minmax(164px, 1fr));
                        gap:40px;
                        margin-bottom:10px;">
            <div class="card  rounded  row gy-2" class="col-md-4" style="width: 13rem; margin-left:258px; "> 


                <img class=" img-fluid" style="width: 100%; height: 20vw; object-fit: cover;" src="../../view/image/<?= $row['image_livre'] ?>" alt="" style="hight=80%">
                <div class="card-body   ">

                        <a href="#">
                            <p class="card-text fs-7 text-light "><?= $row['nom_livre'] ?></p>
                            <p class="card-text fs-7 text-light ">Prix: <?= $row['prix_livre'] ?> DH</p>
                            <p class="card-text fs-7 text-light ">By: <?= $row['editeur_livre'] ?></p>


                        </a>


                        <a href="#"><button type="button" style="color-background:#515151;"><i class='bx bx-plus'></i>View</button></a>
                </div>





            </div>

        <?php
    }
        ?>


        </form>



</div>


         



           <!-- STRAT FOOTER -->
           <div class="footer">
            <div class="container">
              <img  src="view/img/EbookStore.png" width="150px" alt="logowesite" >
              <p>Ebookstore de votre plus grande bibliothèque en ligne</p>
              <div class="social-icons">
               <a href="#"><i class='bx bxs-home' ></i></a>
               <a href="#"><i class='bx bxl-facebook-circle'></i></a>
               <a href="#"></a> <i class='bx bxl-twitter' ></i></a>
               <a href="#"></a> <i class='bx bxl-instagram-alt' ></i></a>
              </div>
              <p class="copyright">&copy; 2022 <span>ebookstore</span> All Right Reserved</p>

            </div>

          </div>




          <!-- END FOOTER -->



          <script src="https://cdnjs.cloudflare.come/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
          <script src="js/cart.js"></script>

       

            



</body>
</html>