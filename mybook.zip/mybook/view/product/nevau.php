<!DOCTYPE html>
<html lang="fr">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>ebookstore</title>
        <!--========== BOX ICONS ==========-->
        <link rel="stylesheet" href="../css/boxicons.min.css">
       <!--========== CSS ==========-->
       <link rel="stylesheet" href="../css/main.css">
       <!-- Google Fonts-->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Jomhuria&family=Work+Sans:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Start Header -->
    <div class="header1" id="header1">
        <div class="container1">
            <a href="../../index.php" class="logo1"><img class="logo1" src="../img/EbookStore.png"   alt="logowesite" ></a>
            <ul class="main-nav1">
                <li>
                    <a href="arabic.php">الكتب العربية</a>   
                 </li>
                 
                
                <li><a href="french.php">LIVRE FRANÇAIS</a>
                   
                </li>
                <li><a href="english.php">LIVRE ENGLAIS</a>
                   
                </li>
                <li><a href="nevau.php">NOUVEAUTÉS</a></li>
            </ul>
                <input class="sherche1" type="text" placeholder="Recherche...">
            <ul class="main-nav1">    
                <li><a href="../?action=login"><i class='bx bx-user-circle bx-md'></i>Mon compte</a></li>
                <li><a href="#"><i class='bx bx-heart bx-sm' ></i></a></li>
                <li>
                    <a href="#" class="cart1">
                      <i class='bx bx-basket bx-sm' ></i>
                    </a>
                </li>
            </ul>
        </div>

    </div>
    <!-- End Header -->
     

  

       
   

         <main>
            <div class="book-card">
              <div class="book-card__cover">
                <div class="book-card__book">
                  <div class="book-card__book-front">
                   <a href="/product/details.html"> <img class="book-card__img" src="../img/eco.jpg" /></a>
                  </div>
                  <div class="book-card__book-back"></div>
                  <div class="book-card__book-side"></div>
                </div>
              </div>
              <div>
                <div class="book-card__title">
                       <a href="product/details.html"> Economistes Les grandes idees tout simplement</a>
                </div>
                <div class="book-card__author">
                    249,00 MAD

                </div>
                <div class="book-card__buttom">
                    <a href="#"> <button class="add-heart"><i class='bx bx-heart bx-sm' ></i> </button></a>
                    <a href="#"> <button class="add-basket"><i class='bx bx-basket bx-sm' ></i> AJOUTER AU PANIER</button> </a>
                </div>
              </div>
            </div>
          </main>

          <!-- STRAT FOOTER -->
          <div class="footer">
            <div class="container">
              <img  src="../img/EbookStore.png" width="150px" alt="logowesite" >
              <p>Ebookstore de votre plus grande bibliothèque en ligne</p>
              <div class="social-icons">
               <a href="#"><i class='bx bxs-home' ></i></a>
               <a href="#"><i class='bx bxl-facebook-circle'></i></a>
               <a href="#"></a> <i class='bx bxl-twitter' ></i></a>
               <a href="#"></a> <i class='bx bxl-instagram-alt' ></i></a>
              </div>
              <p class="copyright">&copy; 2022 <span>ebookstore</span> All Right Reserved</p>

            </div>

          </div>




          <!-- END FOOTER -->


          <script src="https://cdnjs.cloudflare.come/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
          <script src="js/cart.js"></script>

       

            



</body>
</html>