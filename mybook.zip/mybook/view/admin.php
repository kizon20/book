<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!--========== BOX ICONS ==========-->
     <link rel="stylesheet" href="../view/css/boxicons.min.css">
     <!--========== CSS ==========-->
     <title>Admin</title>
     <link rel="icon" href="view/img/icons8-film-reel-50.png">
</head>
<link rel="stylesheet" href="view/css/bootstrap.min.css">
<!-- <link rel="stylesheet" href="../view/image/"> -->
<link rel="stylesheet" href="view/css/main1.css">
<link rel="stylesheet" href="../view/image/">
<!--========== HEADER ==========-->


<body class=" bg-white">
     <header class="header">
          <div class="header__container">
               <a href="?action=logout" name="logout"> <i class='bx bx-log-in '></i> <input class="btn text-card" type="button" value="Déconnexion" /></a>
          </div>
     </header>

     <div class="container mx-auto ">

          <h3 style="text-align:center; color:#000;" style="margin-bottom:125px;">Ajouter un nouveau livre </h3>

          <form action="?action=addlivre" enctype="multipart/form-data" method="post" class="w-75">




               <div>
                    <label for="title" class="form-control-label px-3 text-dark">Nom Livre :</label>
                    <input type="text" name="title" class="text-dark " name="title" placeholder="ENTREZ UN LIVRE DE NOM " required>
               </div>
               <div>
                    <label for="desc" class="form-control-label px-3 text-dark">Resume LIVRE :</label>
                    <input type="text" name="desc" class="text-dark " placeholder="ENTREZ UN LIVRE DE RESUME" required>
               </div>
               <div class="form-group col-sm-6 flex-column d-flex">
                    <label class="form-control-label px-3 text-dark">ISBN Livre :</label>
                    <input type="text" class="text-dark " name="isbn" placeholder="Entrer le livre ISBN">
               </div>
               <div class="form-group col-sm-6 flex-column d-flex">
                    <label class="form-control-label px-3 text-dark" for="der">Prix :</label>
                    <input type="text" class="text-dark " name="prix" placeholder="Entrer le livre PRIX">
               </div>
               <div class="form-group col-sm-6 flex-column d-flex">
                    <label class="form-control-label px-3 text-dark" for="der">Quantite :</label>
                    <input type="text" class="text-dark " name="qunty" placeholder="Entrer le livre quantite ">
               </div>
               <div>
                    <div class="form-group col-sm-6 flex-column d-flex">
                         <label class="form-control-label px-3 text-dark" for="der">EDITEUR LIVRE:</label>
                         <input type="text" class="text-dark " name="editeur" placeholder="ENTREZ UN LIVRE DE EDITEUR">
                    </div>
                    <div class="form-group col-sm-6 flex-column d-flex">
                         <label class="form-control-label px-3 text-dark" for="type">Annee:</label>
                         <input type="text" class="text-dark " name="date" placeholder="ENTREZ UN LIVRE DE ANEE">
                    </div>

               </div>
               <div class="form-group col-sm-6 flex-column d-flex">
                    <label class="form-control-label px-3 text-dark" for="type">Langue :</label>
                    <input type="text" class="text-dark " name="leng" placeholder="ENTREZ UN LIVRE DE LANGUE">
               </div>


     </div>

     </div>


     <br>
     <?php
     // if (isset($_POST['up'])) {
     // }
     ?>

     <div class="  w-50 mx-auto">
          <label for="img" class="text-dark">Choisissez l'image du livre:</label>
          <input type="file" class="text-dark" name="image">
     </div>
     <br>
     <div class="btn d-block w-75 mx-auto">
          <input type="submit" name="sub" value="Envoyer" class="header_btn">
     </div>
     </div>
     </form>

     </div>

</body>

</html>